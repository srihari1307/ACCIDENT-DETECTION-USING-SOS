# ACCIDENT-DETECTION-
IoT based accident detection and emergency SOS Device

Design of an emergency SoS Device that can connect with emergency services and family members in the event of an accident or fall from a 2-Wheelar.
